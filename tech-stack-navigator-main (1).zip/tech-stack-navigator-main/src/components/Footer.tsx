import { Sparkles } from "lucide-react";

const Footer = () => (
  <footer className="gradient-dark py-10">
    <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-2 text-primary-foreground">
        <Sparkles className="w-4 h-4 text-primary" />
        <span className="font-display text-sm font-bold">Styling AI</span>
      </div>
      <p className="text-xs text-primary-foreground/50">
        © 2024 Styling AI. Powered by Advanced AI Technology. All rights reserved.
      </p>
    </div>
  </footer>
);

export default Footer;
