import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, X, Loader2 } from "lucide-react";
import ResultsSection from "./ResultsSection";

const UploadSection = () => {
  const [gender, setGender] = useState<"Male" | "Female">("Male");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith("image/")) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setResults(null);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const f = e.dataTransfer.files[0];
      if (f) handleFile(f);
    },
    [handleFile]
  );

  const clearFile = () => {
    setFile(null);
    setPreview(null);
    setResults(null);
  };

  const analyzeStyle = async () => {
    if (!file) return;
    setLoading(true);
    // Simulate AI analysis (would call Groq API via backend)
    await new Promise((r) => setTimeout(r, 2500));
    setResults({
      skinTone: "Medium",
      rgb: "RGB(186, 154, 132)",
      dressCodes: ["Formal", "Business", "Casual", "Party"],
      outfit:
        gender === "Male"
          ? "A navy blue suit with a white dress shirt, paired with dark brown chinos and loafers."
          : "An elegant emerald green wrap dress paired with nude heels and gold accessories.",
      shirt: { color: gender === "Male" ? "Light Grey" : "Cream", type: gender === "Male" ? "Polo" : "Silk Blouse", brand: gender === "Male" ? "Calvin Klein" : "Zara" },
      pants: { color: "Dark Brown", type: "Chinos", brand: "Bonobos" },
      shoes: { color: "Tan", type: gender === "Male" ? "Loafers" : "Heels", brand: "Gucci" },
      hairstyle: gender === "Male" ? "Fade with Pompadour" : "Loose Waves with Side Part",
      accessories: gender === "Male"
        ? ["Leather Watch", "Silver Necklace", "Brown Belt", "Aviator Sunglasses"]
        : ["Gold Hoop Earrings", "Delicate Necklace", "Bracelet Stack", "Clutch Bag"],
      palette: { primary: "Navy Blue", secondary: "Light Grey", accent: "Tan" },
      whyItWorks:
        "The recommended palette creates a harmonious contrast with your skin tone, enhancing your natural features while maintaining a balanced, stylish look.",
    });
    setLoading(false);
  };

  return (
    <>
      <section id="upload" className="py-24 bg-secondary/50">
        <div className="max-w-3xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-3xl md:text-4xl font-bold text-center text-foreground"
          >
            Let's Style You
          </motion.h2>

          {/* Gender selector */}
          <div className="mt-10 flex items-center justify-center gap-4">
            <span className="text-sm font-medium text-muted-foreground">I am:</span>
            {(["Male", "Female"] as const).map((g) => (
              <button
                key={g}
                onClick={() => setGender(g)}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                  gender === g
                    ? "gradient-primary text-primary-foreground shadow-soft"
                    : "bg-card border border-border text-foreground hover:border-primary"
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          {/* Upload area */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={onDrop}
            onClick={() => !file && inputRef.current?.click()}
            className={`mt-8 border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-colors ${
              file ? "border-primary bg-accent/40" : "border-border hover:border-primary bg-card"
            }`}
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />

            {preview ? (
              <div className="relative inline-block">
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-64 rounded-xl mx-auto object-cover"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    clearFile();
                  }}
                  className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <>
                <Upload className="w-10 h-10 mx-auto text-muted-foreground" />
                <h3 className="mt-4 font-display text-lg font-semibold text-foreground">
                  Drag & Drop Your Photo
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">or click to browse</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Supported: PNG, JPG, JPEG, WEBP (Max 10MB)
                </p>
              </>
            )}
          </motion.div>

          {/* Analyze button */}
          <AnimatePresence>
            {file && !results && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-6 text-center"
              >
                <button
                  onClick={analyzeStyle}
                  disabled={loading}
                  className="gradient-primary text-primary-foreground font-semibold px-10 py-3 rounded-full shadow-soft disabled:opacity-60 inline-flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Analyzing your style...
                    </>
                  ) : (
                    "Get Recommendations"
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* Results */}
      {results && (
        <ResultsSection results={results} onTryAgain={clearFile} />
      )}
    </>
  );
};

export default UploadSection;
