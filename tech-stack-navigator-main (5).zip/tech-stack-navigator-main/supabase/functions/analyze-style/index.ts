import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const GROQ_API_KEY = Deno.env.get("GROQ_API_KEY");
    if (!GROQ_API_KEY) throw new Error("GROQ_API_KEY is not configured");

    const formData = await req.formData();
    const imageFile = formData.get("image") as File | null;
    const gender = (formData.get("gender") as string) || "Male";

    if (!imageFile) {
      return new Response(JSON.stringify({ error: "No image provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Convert image to base64 in chunks to avoid stack overflow
    const arrayBuffer = await imageFile.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const chunkSize = 8192;
    let binary = "";
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
      for (let j = 0; j < chunk.length; j++) {
        binary += String.fromCharCode(chunk[j]);
      }
    }
    const base64 = btoa(binary);
    const mimeType = imageFile.type || "image/jpeg";

    const systemPrompt = `You are StyleAI, an expert fashion consultant and color analyst. Analyze the person in the uploaded photo and provide personalized style recommendations.

You MUST respond with valid JSON only, no markdown, no extra text. Use this exact structure:
{
  "skinTone": "e.g. Fair / Light / Medium / Olive / Tan / Dark / Deep",
  "rgb": "RGB(r, g, b) approximate skin tone color",
  "dressCodes": ["array of 4 suitable dress codes like Formal, Business, Casual, Party, Streetwear, Bohemian, Minimalist, Sporty"],
  "outfit": "A detailed 1-2 sentence outfit recommendation tailored to the person's features and skin tone",
  "shirt": { "color": "recommended color", "type": "shirt type", "brand": "suggested brand" },
  "pants": { "color": "recommended color", "type": "pants type", "brand": "suggested brand" },
  "shoes": { "color": "recommended color", "type": "shoe type", "brand": "suggested brand" },
  "hairstyle": "A specific hairstyle recommendation",
  "accessories": ["4 specific accessory recommendations"],
  "palette": { "primary": "primary color name", "secondary": "secondary color name", "accent": "accent color name" },
  "whyItWorks": "2-3 sentences explaining why these recommendations suit the person's skin tone and features"
}

The person identifies as ${gender}. Tailor all recommendations accordingly. Be specific with brands, colors, and styles. Consider Indian fashion retailers and price points.`;

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${GROQ_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "text", text: "Analyze this person's photo and provide style recommendations." },
              { type: "image_url", image_url: { url: `data:${mimeType};base64,${base64}` } },
            ],
          },
        ],
        temperature: 0.7,
        max_tokens: 1024,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Groq API error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: `Groq API error: ${response.status}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      return new Response(
        JSON.stringify({ error: "No response from AI model" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Extract JSON from the response (handle potential markdown wrapping)
    let jsonStr = content.trim();
    if (jsonStr.startsWith("```")) {
      jsonStr = jsonStr.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "");
    }

    const parsed = JSON.parse(jsonStr);

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("analyze-style error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
