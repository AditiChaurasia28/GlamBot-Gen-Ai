import { motion } from "framer-motion";
import { Camera, Palette, ShoppingBag, Star } from "lucide-react";

const features = [
  {
    icon: Camera,
    title: "Instant Analysis",
    desc: "Upload a photo and get AI-powered styling recommendations in seconds",
  },
  {
    icon: Palette,
    title: "Color Matching",
    desc: "Get recommendations perfectly matched to your skin tone and complexion",
  },
  {
    icon: ShoppingBag,
    title: "Product Links",
    desc: "Direct shopping links to purchase recommended items from top brands",
  },
  {
    icon: Star,
    title: "Professional Tips",
    desc: "Learn hairstyle, accessories, and styling tips from fashion experts",
  },
];

const FeaturesSection = () => (
  <section id="features" className="py-24 bg-background">
    <div className="max-w-7xl mx-auto px-6">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-display text-3xl md:text-4xl font-bold text-center text-foreground"
      >
        Why Choose Styling AI?
      </motion.h2>

      <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-border rounded-xl p-6 shadow-card hover:shadow-soft transition-shadow text-center"
          >
            <div className="w-14 h-14 mx-auto rounded-xl bg-secondary flex items-center justify-center mb-4">
              <f.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-display text-lg font-semibold text-card-foreground">{f.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default FeaturesSection;
