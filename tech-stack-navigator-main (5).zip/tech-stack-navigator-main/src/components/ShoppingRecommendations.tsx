import { motion } from "framer-motion";
import { ExternalLink, ShoppingBag } from "lucide-react";

import shirtMale from "@/assets/products/shirt-male.jpg";
import pantsMale from "@/assets/products/pants-male.jpg";
import shoesMale from "@/assets/products/shoes-male.jpg";
import accessoriesMale from "@/assets/products/accessories-male.jpg";
import shirtFemale from "@/assets/products/shirt-female.jpg";
import shoesFemale from "@/assets/products/shoes-female.jpg";
import accessoriesFemale from "@/assets/products/accessories-female.jpg";

interface Product {
  name: string;
  brand: string;
  price: string;
  image: string;
  links: { store: string; url: string }[];
}

const maleProducts: Product[] = [
  {
    name: "Navy Blue Suit Jacket",
    brand: "Calvin Klein",
    price: "₹8,999",
    image: shirtMale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=calvin+klein+navy+suit+jacket" },
      { store: "Myntra", url: "https://www.myntra.com/suits?q=calvin+klein+navy" },
      { store: "Ajio", url: "https://www.ajio.com/search/?text=navy+suit+jacket" },
    ],
  },
  {
    name: "Dark Brown Chinos",
    brand: "Bonobos",
    price: "₹3,499",
    image: pantsMale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=dark+brown+chinos+men" },
      { store: "Myntra", url: "https://www.myntra.com/chinos?q=dark+brown+chinos" },
      { store: "Ajio", url: "https://www.ajio.com/search/?text=brown+chinos" },
    ],
  },
  {
    name: "Tan Leather Loafers",
    brand: "Gucci",
    price: "₹6,999",
    image: shoesMale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=tan+leather+loafers+men" },
      { store: "Myntra", url: "https://www.myntra.com/loafers?q=tan+leather+loafers" },
      { store: "Zara", url: "https://www.zara.com/in/en/search?searchTerm=tan+loafers" },
    ],
  },
  {
    name: "Watch & Sunglasses Set",
    brand: "Fossil & Ray-Ban",
    price: "₹12,499",
    image: accessoriesMale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=fossil+watch+aviator+sunglasses" },
      { store: "Myntra", url: "https://www.myntra.com/accessories?q=watch+sunglasses" },
    ],
  },
];

const femaleProducts: Product[] = [
  {
    name: "Emerald Wrap Dress",
    brand: "Zara",
    price: "₹5,999",
    image: shirtFemale,
    links: [
      { store: "Zara", url: "https://www.zara.com/in/en/search?searchTerm=emerald+wrap+dress" },
      { store: "Myntra", url: "https://www.myntra.com/dresses?q=emerald+green+wrap+dress" },
      { store: "Ajio", url: "https://www.ajio.com/search/?text=green+wrap+dress" },
    ],
  },
  {
    name: "Nude Heels",
    brand: "Gucci",
    price: "₹4,999",
    image: shoesFemale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=nude+heels+women" },
      { store: "Myntra", url: "https://www.myntra.com/heels?q=nude+heels" },
      { store: "Zara", url: "https://www.zara.com/in/en/search?searchTerm=nude+heels" },
    ],
  },
  {
    name: "Gold Jewelry Set",
    brand: "Tanishq",
    price: "₹8,499",
    image: accessoriesFemale,
    links: [
      { store: "Amazon", url: "https://www.amazon.in/s?k=gold+hoop+earrings+necklace+set" },
      { store: "Myntra", url: "https://www.myntra.com/jewellery-set?q=gold+jewelry+set" },
    ],
  },
];

const storeColors: Record<string, string> = {
  Amazon: "bg-amber-500 hover:bg-amber-600",
  Myntra: "bg-pink-500 hover:bg-pink-600",
  Zara: "bg-zinc-800 hover:bg-zinc-900",
  Ajio: "bg-indigo-500 hover:bg-indigo-600",
};

const ProductCard = ({ product, index }: { product: Product; index: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.1 }}
    className="bg-card border border-border rounded-2xl overflow-hidden shadow-card group"
  >
    <div className="relative overflow-hidden">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500"
      />
      <div className="absolute top-3 right-3 bg-card/90 backdrop-blur-sm rounded-full px-3 py-1">
        <span className="text-sm font-semibold text-foreground">{product.price}</span>
      </div>
    </div>

    <div className="p-5">
      <p className="text-xs font-medium text-primary uppercase tracking-wider">{product.brand}</p>
      <h4 className="font-display text-lg font-semibold text-foreground mt-1">{product.name}</h4>

      <div className="mt-4 flex flex-wrap gap-2">
        {product.links.map((link) => (
          <a
            key={link.store}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold text-white transition-colors ${storeColors[link.store] || "bg-primary hover:bg-primary/90"}`}
          >
            <ExternalLink className="w-3 h-3" />
            {link.store}
          </a>
        ))}
      </div>
    </div>
  </motion.div>
);

interface ShoppingRecommendationsProps {
  gender: "Male" | "Female";
}

const ShoppingRecommendations = ({ gender }: ShoppingRecommendationsProps) => {
  const products = gender === "Male" ? maleProducts : femaleProducts;

  return (
    <section className="py-20 bg-secondary/30">
      <div className="max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4">
            <ShoppingBag className="w-4 h-4" />
            Shop the Look
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            Purchase Your Recommended Items
          </h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
            Click on any store badge to shop directly. Curated from top retailers for the best price and quality.
          </p>
        </motion.div>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product, i) => (
            <ProductCard key={product.name} product={product} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ShoppingRecommendations;
