import { motion } from "framer-motion";
import { RotateCcw } from "lucide-react";

interface ResultsProps {
  results: {
    skinTone: string;
    rgb: string;
    dressCodes: string[];
    outfit: string;
    shirt: { color: string; type: string; brand: string };
    pants: { color: string; type: string; brand: string };
    shoes: { color: string; type: string; brand: string };
    hairstyle: string;
    accessories: string[];
    palette: { primary: string; secondary: string; accent: string };
    whyItWorks: string;
  };
  onTryAgain: () => void;
}

const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="bg-card border border-border rounded-xl p-6 shadow-card">
    <h3 className="font-display text-lg font-semibold text-card-foreground mb-3">{title}</h3>
    {children}
  </div>
);

const ResultsSection = ({ results, onTryAgain }: ResultsProps) => (
  <section className="py-24 bg-background">
    <div className="max-w-5xl mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground">
          Your Personalized Style Profile
        </h2>
        <button
          onClick={onTryAgain}
          className="mt-4 inline-flex items-center gap-2 text-sm text-primary hover:underline"
        >
          <RotateCcw className="w-4 h-4" /> Try Again
        </button>
      </motion.div>

      <div className="mt-12 grid md:grid-cols-2 gap-6">
        {/* Skin Tone */}
        <Card title="Skin Tone Analysis">
          <p className="text-sm text-muted-foreground">
            Detected: <span className="font-semibold text-foreground">{results.skinTone}</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1">{results.rgb}</p>
        </Card>

        {/* Dress Codes */}
        <Card title="Dress Codes">
          <div className="flex flex-wrap gap-2">
            {results.dressCodes.map((d) => (
              <span key={d} className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-medium">
                {d}
              </span>
            ))}
          </div>
        </Card>

        {/* Outfit */}
        <Card title="Suggested Outfit">
          <p className="text-sm text-muted-foreground leading-relaxed">{results.outfit}</p>
        </Card>

        {/* Details */}
        <Card title="Clothing Details">
          <div className="space-y-2 text-sm text-muted-foreground">
            <p><span className="font-medium text-foreground">Shirt:</span> {results.shirt.color} {results.shirt.type} — {results.shirt.brand}</p>
            <p><span className="font-medium text-foreground">Pants:</span> {results.pants.color} {results.pants.type} — {results.pants.brand}</p>
            <p><span className="font-medium text-foreground">Shoes:</span> {results.shoes.color} {results.shoes.type} — {results.shoes.brand}</p>
          </div>
        </Card>

        {/* Hairstyle */}
        <Card title="Hairstyle">
          <p className="text-sm text-muted-foreground">{results.hairstyle}</p>
        </Card>

        {/* Accessories */}
        <Card title="Accessories">
          <ul className="space-y-1">
            {results.accessories.map((a, i) => (
              <li key={i} className="text-sm text-muted-foreground">• {a}</li>
            ))}
          </ul>
        </Card>

        {/* Color Palette */}
        <Card title="Color Palette">
          <div className="space-y-1 text-sm text-muted-foreground">
            <p><span className="font-medium text-foreground">Primary:</span> {results.palette.primary}</p>
            <p><span className="font-medium text-foreground">Secondary:</span> {results.palette.secondary}</p>
            <p><span className="font-medium text-foreground">Accent:</span> {results.palette.accent}</p>
          </div>
        </Card>

        {/* Why It Works */}
        <Card title="Why It Works">
          <p className="text-sm text-muted-foreground leading-relaxed">{results.whyItWorks}</p>
        </Card>
      </div>
    </div>
  </section>
);

export default ResultsSection;
