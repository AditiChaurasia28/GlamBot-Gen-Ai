import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, X } from "lucide-react";
import { toast } from "sonner";
import ResultsSection from "./ResultsSection";
import ShoppingRecommendations from "./ShoppingRecommendations";
import AnalysisProgress from "./AnalysisProgress";

const UploadSection = () => {
  const [gender, setGender] = useState<"Male" | "Female">("Male");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith("image/")) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setResults(null);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const f = e.dataTransfer.files[0];
      if (f) handleFile(f);
    },
    [handleFile]
  );

  const clearFile = () => {
    setFile(null);
    setPreview(null);
    setResults(null);
  };

  const analyzeWithGroq = async () => {
    if (!file) return;
    try {
      const formData = new FormData();
      formData.append("image", file);
      formData.append("gender", gender);

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-style`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: formData,
        }
      );

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || `API error ${response.status}`);
      }

      const data = await response.json();
      setResults(data);
    } catch (error: any) {
      console.error("Analysis failed:", error);
      toast.error(error.message || "Failed to analyze image. Please try again.");
    }
    setLoading(false);
  };

  return (
    <>
      <section id="upload" className="py-24 bg-secondary/50">
        <div className="max-w-3xl mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-display text-3xl md:text-4xl font-bold text-center text-foreground"
          >
            Let's Style You
          </motion.h2>

          {/* Gender selector */}
          <div className="mt-10 flex items-center justify-center gap-4">
            <span className="text-sm font-medium text-muted-foreground">I am:</span>
            {(["Male", "Female"] as const).map((g) => (
              <button
                key={g}
                onClick={() => setGender(g)}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                  gender === g
                    ? "gradient-primary text-primary-foreground shadow-soft"
                    : "bg-card border border-border text-foreground hover:border-primary"
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          {/* Upload area */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={onDrop}
            onClick={() => !file && inputRef.current?.click()}
            className={`mt-8 border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-colors ${
              file ? "border-primary bg-accent/40" : "border-border hover:border-primary bg-card"
            }`}
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />

            {preview ? (
              <div className="relative inline-block">
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-64 rounded-xl mx-auto object-cover"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    clearFile();
                  }}
                  className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <>
                <Upload className="w-10 h-10 mx-auto text-muted-foreground" />
                <h3 className="mt-4 font-display text-lg font-semibold text-foreground">
                  Drag & Drop Your Photo
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">or click to browse</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  Supported: PNG, JPG, JPEG, WEBP (Max 10MB)
                </p>
              </>
            )}
          </motion.div>

          {/* Analyze button or progress */}
          <AnimatePresence>
            {file && !results && !loading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mt-6 text-center"
              >
                <button
                  onClick={() => setLoading(true)}
                  className="gradient-primary text-primary-foreground font-semibold px-10 py-3 rounded-full shadow-soft inline-flex items-center gap-2"
                >
                  Get Recommendations
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {file && loading && !results && (
            <AnalysisProgress onComplete={analyzeWithGroq} />
          )}
        </div>
      </section>

      {/* Results */}
      {results && (
        <>
          <ResultsSection results={results} onTryAgain={clearFile} />
          <ShoppingRecommendations gender={gender} />
        </>
      )}
    </>
  );
};

export default UploadSection;
