import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Brain, Palette, Shirt, Scissors, Sparkles, CheckCircle2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const steps = [
  { icon: Brain, label: "Detecting facial features...", duration: 1200 },
  { icon: Palette, label: "Analyzing skin tone & undertone...", duration: 1400 },
  { icon: Shirt, label: "Generating outfit recommendations...", duration: 1000 },
  { icon: Scissors, label: "Matching hairstyle suggestions...", duration: 800 },
  { icon: Sparkles, label: "Building your color palette...", duration: 600 },
];

interface AnalysisProgressProps {
  onComplete: () => void;
}

const AnalysisProgress = ({ onComplete }: AnalysisProgressProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (currentStep >= steps.length) {
      onComplete();
      return;
    }

    const stepDuration = steps[currentStep].duration;
    const targetProgress = ((currentStep + 1) / steps.length) * 100;
    const startProgress = (currentStep / steps.length) * 100;

    // Animate progress smoothly
    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + (targetProgress - startProgress) / (stepDuration / 50);
        return next >= targetProgress ? targetProgress : next;
      });
    }, 50);

    const timeout = setTimeout(() => {
      clearInterval(interval);
      setProgress(targetProgress);
      setCurrentStep((s) => s + 1);
    }, stepDuration);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [currentStep, onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-lg mx-auto mt-8 bg-card border border-border rounded-2xl p-8 shadow-card"
    >
      <div className="text-center mb-6">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 mx-auto rounded-full gradient-primary flex items-center justify-center mb-3"
        >
          <Brain className="w-6 h-6 text-primary-foreground" />
        </motion.div>
        <h3 className="font-display text-xl font-bold text-foreground">AI Analyzing Your Photo</h3>
        <p className="text-xs text-muted-foreground mt-1">Powered by StyleAI Engine</p>
      </div>

      <Progress value={progress} className="h-2 mb-6" />

      <div className="space-y-3">
        {steps.map((step, i) => {
          const Icon = step.icon;
          const isDone = i < currentStep;
          const isActive = i === currentStep;

          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: i <= currentStep ? 1 : 0.3, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`flex items-center gap-3 text-sm transition-colors ${
                isDone
                  ? "text-primary"
                  : isActive
                  ? "text-foreground"
                  : "text-muted-foreground/40"
              }`}
            >
              {isDone ? (
                <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
              ) : isActive ? (
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.8 }}>
                  <Icon className="w-4 h-4 shrink-0" />
                </motion.div>
              ) : (
                <Icon className="w-4 h-4 shrink-0" />
              )}
              <span className={isDone ? "line-through opacity-70" : isActive ? "font-medium" : ""}>
                {step.label}
              </span>
            </motion.div>
          );
        })}
      </div>

      <p className="text-center text-xs text-muted-foreground mt-6">
        {Math.round(progress)}% complete
      </p>
    </motion.div>
  );
};

export default AnalysisProgress;
