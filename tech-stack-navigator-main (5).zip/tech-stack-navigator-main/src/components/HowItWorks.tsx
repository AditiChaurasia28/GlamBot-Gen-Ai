import { motion } from "framer-motion";
import { Upload, Cpu, Sparkles, ShoppingBag } from "lucide-react";

const steps = [
  { icon: Upload, num: "1", title: "Upload Your Photo", desc: "Share a clear photo of yourself for analysis" },
  { icon: Cpu, num: "2", title: "AI Analysis", desc: "Our AI detects your skin tone and analyzes your features" },
  { icon: Sparkles, num: "3", title: "Get Recommendations", desc: "Receive personalized styling advice tailored to you" },
  { icon: ShoppingBag, num: "4", title: "Shop & Style", desc: "Access direct links to purchase recommended items" },
];

const HowItWorks = () => (
  <section id="about" className="py-24 bg-background">
    <div className="max-w-7xl mx-auto px-6">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="font-display text-3xl md:text-4xl font-bold text-center text-foreground"
      >
        How Styling AI Works
      </motion.h2>

      <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((s, i) => (
          <motion.div
            key={s.num}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.12 }}
            className="text-center"
          >
            <div className="w-16 h-16 mx-auto rounded-2xl gradient-primary flex items-center justify-center text-primary-foreground shadow-soft">
              <s.icon className="w-7 h-7" />
            </div>
            <span className="mt-4 block text-xs font-bold text-primary">STEP {s.num}</span>
            <h3 className="mt-1 font-display text-lg font-semibold text-foreground">{s.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default HowItWorks;
