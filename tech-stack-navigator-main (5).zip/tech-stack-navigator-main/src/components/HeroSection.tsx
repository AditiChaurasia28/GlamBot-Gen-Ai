import { motion } from "framer-motion";
import heroImage from "@/assets/hero-fashion.jpg";

const HeroSection = () => (
  <section
    id="home"
    className="relative min-h-screen flex items-center overflow-hidden"
  >
    {/* Background image with overlay */}
    <div className="absolute inset-0">
      <img src={heroImage} alt="Fashion background" className="w-full h-full object-cover" />
      <div className="absolute inset-0 gradient-hero opacity-80" />
    </div>

    <div className="relative z-10 max-w-7xl mx-auto px-6 py-32">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-2xl"
      >
        <h1 className="font-display text-5xl md:text-7xl font-bold text-primary-foreground leading-tight">
          Your Personal AI Fashion Stylist
        </h1>
        <p className="mt-6 text-lg text-primary-foreground/80 font-body max-w-lg">
          Upload your photo and get personalized styling recommendations based on your skin tone
        </p>
        <motion.a
          href="#upload"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="mt-8 inline-block gradient-primary text-primary-foreground font-semibold px-8 py-4 rounded-full shadow-soft text-sm tracking-wide"
        >
          Get Started
        </motion.a>
      </motion.div>
    </div>

    {/* Floating shapes */}
    <div className="absolute top-1/4 right-10 w-20 h-20 rounded-full bg-primary-foreground/10 animate-float" />
    <div className="absolute bottom-1/3 right-1/4 w-12 h-12 rounded-full bg-primary-foreground/5 animate-float [animation-delay:1s]" />
  </section>
);

export default HeroSection;
